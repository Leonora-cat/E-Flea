/** When your routing table is too long, you can split it into small modules **/

import Layout from '@/layout'

const tableRouter = {
  path: '/View Tables',
  component: Layout,
  redirect: '/table/complex-table',
  name: 'View Tables',
  meta: {
    title: 'View Tables',
    icon: 'table'
  },
  children: [
    // {
    //   path: 'dynamic-table',
    //   component: () => import('@/views/table/dynamic-table/index'),
    //   name: 'DynamicTable',
    //   meta: { title: 'Dynamic Table' }
    // }
    // {
    //   path: 'drag-table',
    //   component: () => import('@/views/table/drag-table'),
    //   name: 'DragTable',
    //   meta: { title: 'Drag Table' }
    // },
    // {
    //   path: 'inline-edit-table',
    //   component: () => import('@/views/table/inline-edit-table'),
    //   name: 'InlineEditTable',
    //   meta: { title: 'Inline Edit' }
    // },
    {
      path: 'productTable',
      component: () => import('@/views/table/productTable'),
      name: 'ComplexTable',
      meta: { title: 'Product Table' }
    },
    {
      path: 'userTable',
      component: () => import('@/views/table/userTable'),
      name: 'ComplexTable',
      meta: { title: 'User Table' }
    }
  ]
}
export default tableRouter
