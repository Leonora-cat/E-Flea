<template>
  <el-form>
    <el-form-item label="Name">
      <el-input v-model.trim="user.name" :readonly="true" />
    </el-form-item>
    <el-form-item label="Email">
      <el-input v-model.trim="user.email" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submit">Update</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import axios from 'axios'

export default {
  props: {
    user: {
      type: Object,
      default: () => {
        return {
          name: '',
          email: ''
        }
      }
    }
  },
  methods: {
    submit() {
      console.log(this.user.email)
      axios({
        url: 'http://127.0.0.1:9000/admin/update' + this.user.email,
        method: 'get'
      }).then((res) => {
        console.log(res.data)
        if (res.status == 'success') {
          this.$message({
            message: 'User information has been updated successfully',
            type: 'success',
            duration: 5 * 1000
          })
        }

        console.log(this.admin)
      })
    }

  }
}
</script>
