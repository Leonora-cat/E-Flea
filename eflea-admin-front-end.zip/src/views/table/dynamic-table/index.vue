<template>
  <div class="app-container">

<!--    <div style="margin:30px 0 5px 20px">-->
<!--      Not fixed header, sorted by click order-->
<!--    </div>-->
    <unfixed-thead />
  </div>
</template>

<script>

import UnfixedThead from './components/UnfixedThead'

export default {
  name: 'DynamicTable',
  components: { UnfixedThead }
}
</script>

